# TCP Congestion Control and Bufferbloat


In this assignment, you will create your own network simulation to investigate the dynamics of TCP and how seemingly minor configuration decisions made by network operators can have major performance effects. 

As discussed in lecture, TCP is a protocol for obtaining reliable transmission over an unreliable packet-switched network. Another important component of TCP is congestion control, i.e. limiting end host send rates to prevent network infrastructure from getting overwhelmed with traffic. 

However, networks can suffer congestion-related performance issues even when end hosts use TCP. One such issue, known as bufferbloat, can occur when packet buffers on routers and switches are too large. 

In this assignment, you will use Mininet, a useful tool for network experiments, to emulate a small network and collect various performance statistics relevant to TCP congestion control and bufferbloat. This will allow you to reason about the effects of TCP and router configuration on network performance.   

**Put your name and netID in the cell below:**


**Name:Kevinyao**

**NetId:10224507041**

## Background

#### TCP Congestion Window Size
The TCP congestion window size parameter, typically styled "cwnd," is maintained by the sender and determines how much traffic can be outstanding (sent but not acknowledged) at any time. There are many algorithms for controlling the value of cwnd during a TCP connection, all with the goal of maximizing the connection's throughput while preventing congestion. The additive increase and multiplicative decrease algorithm was discussed in lecture.

#### Bufferbloat
Bufferbloat is a phenomenon that happens when a switching device is configured to use excessively large buffers, which can in turn cause high latency and packet delay variation (jitter). This can happen even in a typical home network like the following:
<img width=600 src="figures/home-network.png">
Here, the end host in the home network is connected to the home router. The home router is then connected, via cable or DSL, to a headend router run by the Internet service provider (ISP). By simulating and experimenting with a similar network in Mininet, you will see how bufferbloat causes poor performance.

#### Mininet
Mininet is a network emulator with which you can create a custom network of virtual hosts, switches, controllers, and links, all on a single computer. The virtual devices in the emulated network can run real programs; anything that can run on linux can run on a Mininet device too. This makes Mininet a valuable tool for fast and easy simulation of network protcols and measurements. This [Introduction to Mininet](https://github.com/mininet/mininet/wiki/Introduction-to-Mininet) is a useful guide for getting started with Mininet's Python API.  The [Mininet website](http://www.mininet.org) has additional resources if you are interested.

## Part A: Network Simulation & Measurement
To start, you should first create the following network using Mininet's Python API, which emulates a typical home netowrk:
<img width=450 src="figures/mininet-topo.png">
Here h1 is a web server that has a fast connection (1Gb/s) to your home router. The home router has a slow downlink connection (1.5Mb/s) to your home computer. The round-trip propagation delay, or the minimum RTT between h1 and h2 is 20ms.  The router buffer (queue) size will be the parameterized independent variable in your simulation.

To create a custom topology in Mininet, we extend the mininet.topo.Topo class. We have already added the switch (the router) to topology for you. You need to add h1, h2, and links with appropriate characteristics to create the setting specified in the image above.  The first few subsections of the [Working with Mininet](https://github.com/mininet/mininet/wiki/Introduction-to-Mininet#working) section of the Mininet guide describe how to add elements to a topology and set performance parameters. 


```python
from mininet.topo import Topo

class BBTopo(Topo):
    "Simple topology for bufferbloat experiment."

    def __init__(self, queue_size):
        super(BBTopo, self).__init__()
        
        # Create switch s0 (the router)
        self.addSwitch('s0')
        
        # TODO: Create two hosts with names 'h1' and 'h2'
        self.addHost('h1')
        self.addHost('h2')
        
        # TODO: Add links with appropriate bandwidth, delay, and queue size parameters. 
        #       Set the router queue size using the queue_size argument
        #       Set bandwidths/latencies using the bandwidths and minimum RTT given in the network diagram above
        self.addLink( 'h1', 's0', bw=1000, delay='10ms',
                          max_queue_size=queue_size)
        self.addLink( 'h2', 's0', bw=1.5, delay='10ms',
                          max_queue_size=queue_size)
        
        return
```

Next, we need a couple of helper functions to generate traffic between the two hosts. The following function starts a long-lived TCP flow which sends data from h1 to h2 using **iperf**. [Iperf](https://iperf.fr/) is "a tool for active measurements of the maximum achievable bandwidth on IP networks."  You can think of this iperf traffic like a one-way video call. It continually attempts to send a high volume of traffic from the web server h1 to the home computer h2. 

The following function receives one argument called `net`, which is an instance of mininet with a BBTopo topology that we have created above. We have written the part for the iperf server (h2). Notice that in iperf, server is the one that receives data, which should be the home computer h2. You need to complete the function to also start iperf on the iperf client (h1). The iperf session should run for the number of seconds given in the `experiment_time` argument.

You will need to use the `popen` function to run shell commands on a mininet host. The first argument to `popen` is a string command just like you would run in your shell. The second argument should be `shell=True`. You will need to look up the appropriate command line options to run iperf as a client for a given amount of time in the documentation here: [https://iperf.fr/iperf-doc.php#3doc](https://iperf.fr/iperf-doc.php#3doc). You will also need to include the IP address of h2 in your iperf command. This IP address can be accessed with the `h2.IP()` method.  


```python
def start_iperf(net, experiment_time):
    # Start a TCP server on host 'h2' using perf. 
    # The -s parameter specifies server mode
    # The -w 16m parameter ensures that the TCP flow is not receiver window limited (not necessary for client)
    print "Starting iperf server"
    h2 = net.get('h2')
    server = h2.popen("iperf -s -w 16m", shell=True)
    
    # TODO: Start an TCP client on host 'h1' using iperf. 
    #       Ensure that the client runs for experiment_time seconds
    print "Starting iperf client"
    h1 = net.get('h1')
    client = h1.popen("iperf -c {server_ip} -t {time}".format(server_ip=h2.IP(), time=experiment_time), shell=True)
```

Next, you need to complete the following function that starts a back-to-back ping train from h1 to h2 to measure RTTs. A ping should be sent every 0.1 seconds. Results should be redirected from stdout to the `outfile` argument.

As before, `net` is an instance of mininet with a BBTopo topology. As before, you will need to use `popen`.  The command argument to `popen` can redirect stdout using `>` just like a normal shell command.  Read the man page for `ping` for details on available command line arguments. Make sure the second argument to `popen` is `shell=True`.


```python
def start_ping(net, outfile="pings.txt"):
    # TODO: Start a ping train from h1 to h2 with 0.1 seconds between pings, redirecting stdout to outfile
    print "Starting ping train"
    h1 = net.get('h1')
    h2 = net.get('h2')
    ping_command = "ping -i 0.1 {} > {}".format(h2.IP(), outfile)

    # Start the ping train and redirect stdout to the outfile
    h1.popen(ping_command, shell=True)
```

Next, we develop some helper functions to measure the congestion window of the TCP traffic. This will let us analyze at the dynamics of the TCP connections in the mininet network. The following functions are already complete.


```python
from subprocess import Popen
import os

def start_tcpprobe(outfile="cwnd.txt"):
    Popen("sudo cat /proc/net/tcpprobe > " + outfile, shell=True)

def stop_tcpprobe():
    Popen("killall -9 cat", shell=True).wait()
```

We then create a helper function that monitors the queue length on a given interface. This will let us analyze how the number of packets in router buffer queues affects performance. This function is already complete.


```python
from multiprocessing import Process
from monitor import monitor_qlen

def start_qmon(iface, interval_sec=0.1, outfile="q.txt"):
    monitor = Process(target=monitor_qlen,
                      args=(iface, interval_sec, outfile))
    monitor.start()
    return monitor
```

We also need a helper function that starts a webserver on h1. This function is already complete.


```python
from time import sleep

def start_webserver(net):
    h1 = net.get('h1')
    proc = h1.popen("python http/webserver.py", shell=True)
    sleep(1)
    return [proc]
```

Finally, we need a helper function that runs on h2, fetches the website from h1 every 3 seconds for `experiment_time`, and prints the average and standard deviation of the download times. This function is already complete


```python
from time import time
from numpy import mean, std
from time import sleep

def fetch_webserver(net, experiment_time):
    h2 = net.get('h2')
    h1 = net.get('h1')
    download_times = []
    
    start_time = time()
    while True:
        sleep(3)
        now = time()
        if now - start_time > experiment_time:
            break
        fetch = h2.popen("curl -o /dev/null -s -w %{time_total} ", h1.IP(), shell=True)
        download_time, _ = fetch.communicate()
        print "Download time: {0}, {1:.1f}s left...".format(download_time, experiment_time - (now-start_time))
        download_times.append(float(download_time))
        
    average_time = mean(download_times)
    std_time = std(download_times)
    print "\nDownload Times: {}s average, {}s stddev\n".format(average_time, std_time)
```

Now, we need to put together all the pieces to create the network, start all the traffic, and make the measurements. 

The following `bufferbloat()` function should:
* create a `BBTopo` object
* start the TCP and queue monitors
* start a long-lived TCP flow using iperf
* start the ping train
* start the webserver
* Periodically download the index.html web page from h1 and measure how long it takes to fetch it 

Note that the long lived flow, ping train, and webserver downloads should all be happening simultaneously. Once you have completed the assignment steps up until here, complete the sections marked `TODO` in the below `bufferbloat()` function. Each TODO section requires adding one line to call a function defined above.


```python
from mininet.node import CPULimitedHost, OVSController
from mininet.link import TCLink
from mininet.net import Mininet
from mininet.log import lg, info
from mininet.util import dumpNodeConnections

from time import time
import os
from subprocess import call

def bufferbloat(queue_size, experiment_time, experiment_name):
    # Don't forget to use the arguments!
    
    # Set the cwnd control algorithm to "reno" (half cwnd on 3 duplicate acks)
    #    Modern Linux uses CUBIC-TCP by default that doesn't have the usual sawtooth
    #    behaviour.  For those who are curious, replace reno with cubic
    #    see what happens...
    os.system("sysctl -w net.ipv4.tcp_congestion_control=reno")
    
    # create the topology and network
    topo = BBTopo(queue_size)
    net = Mininet(topo=topo, host=CPULimitedHost, link=TCLink, 
                  controller= OVSController)
    net.start()

    # Print the network topology 
    dumpNodeConnections(net.hosts)
    
    # Performs a basic all pairs ping test to ensure the network set up properly
    net.pingAll()
    
    # Start monitoring TCP cwnd size
    outfile = "{}_cwnd.txt".format(experiment_name)
    start_tcpprobe(outfile)

    # TODO: Start monitoring the queue sizes with the start_qmon() function.
    #       Fill in the iface argument with "s0-eth2" if the link from s0 to h2
    #       is added second in BBTopo or "s0-eth1" if the link from s0 to h2
    #       is added first in BBTopo. This is because we want to measure the 
    #       number of packets in the outgoing queue from s0 to h2. 
    outfile = "{}_qsize.txt".format(experiment_name)
    qmon = start_qmon(iface="s0-eth2", outfile=outfile)
    
    
    # TODO: Start the long lived TCP connections with the start_iperf() function
    start_iperf(net,experiment_time)
    
    # TODO: Start pings with the start_ping() function
    outfile = "{}_pings.txt".format(experiment_name)
    start_ping(net,outfile=outfile)
    
    # TODO: Start the webserver with the start_webserver() function
    start_webserver(net)
    
    # TODO: Measure and print website download times with the fetch_webserver() function
    fetch_webserver(net,experiment_time)
    
    # Stop probing 
    stop_tcpprobe()
    qmon.terminate()
    net.stop()
    
    # Ensure that all processes you create within Mininet are killed.
    Popen("pgrep -f webserver.py | xargs kill -9", shell=True).wait()
    call(["mn", "-c"])
```

Once you have completed all the steps above, use the `bufferbloat()` function to run the experiment twice, once with queue size of a 20 packets and then queue size of 100 packets. Make sure to run the experiments long enough to see the dynamics of TCP, like the sawtooth behavior of cwnd, in your results (300 seconds should be good).  Choose `experiment_name` arguments that reflect the queue size


```python
from subprocess import call
call(["mn", "-c"])

# TODO: call the bufferbloat function twice, once with queue size of 20 packets and once with a queue size of 100.
bufferbloat(20, 300, "experiment_20_packets")
bufferbloat(100, 300, "experiment_100_packets")

```

    h1 h1-eth0:s0-eth1
    h2 h2-eth0:s0-eth2
    *** Ping: testing ping reachability
    h1 -> h2 
    h2 -> h1 
    *** Results: 0% dropped (2/2 received)


    Starting iperf server
    Starting iperf client
    Starting ping train
    Download time: 0.624, 297.0s left...
    Download time: 1.068, 293.3s left...
    Download time: 0.560, 289.1s left...
    Download time: 1.669, 285.5s left...
    Download time: 0.558, 280.7s left...
    Download time: 0.569, 277.1s left...
    Download time: 1.508, 273.5s left...
    Download time: 0.557, 268.9s left...
    Download time: 1.128, 265.3s left...
    Download time: 0.541, 261.1s left...
    Download time: 1.555, 257.5s left...
    Download time: 0.534, 252.9s left...
    Download time: 0.536, 249.2s left...
    Download time: 1.949, 245.6s left...
    Download time: 2.689, 240.6s left...
    Download time: 0.508, 234.8s left...
    Download time: 0.844, 231.3s left...
    Download time: 0.557, 227.3s left...
    Download time: 1.481, 223.7s left...
    Download time: 0.590, 219.1s left...
    Download time: 0.546, 215.4s left...
    Download time: 1.915, 211.8s left...
    Download time: 1.503, 206.8s left...
    Download time: 1.686, 202.2s left...
    Download time: 3.235, 197.4s left...
    Download time: 2.051, 191.2s left...
    Download time: 1.483, 186.0s left...
    Download time: 1.467, 181.5s left...
    Download time: 0.556, 176.9s left...
    Download time: 1.550, 173.3s left...
    Download time: 0.567, 168.7s left...
    Download time: 3.279, 165.0s left...
    Download time: 1.335, 158.7s left...
    Download time: 2.223, 154.3s left...
    Download time: 0.504, 149.0s left...
    Download time: 1.688, 145.4s left...
    Download time: 3.234, 140.6s left...
    Download time: 1.004, 134.3s left...
    Download time: 0.576, 130.2s left...
    Download time: 2.189, 126.6s left...
    Download time: 0.600, 121.3s left...
    Download time: 0.494, 117.6s left...
    Download time: 1.131, 114.1s left...
    Download time: 1.505, 109.9s left...
    Download time: 0.510, 105.3s left...
    Download time: 1.522, 101.8s left...
    Download time: 0.559, 97.2s left...
    Download time: 0.493, 93.5s left...
    Download time: 1.506, 89.9s left...
    Download time: 0.572, 85.4s left...
    Download time: 0.501, 81.7s left...
    Download time: 1.504, 78.2s left...
    Download time: 0.577, 73.6s left...
    Download time: 0.563, 70.0s left...
    Download time: 1.801, 66.3s left...
    Download time: 0.557, 61.5s left...
    Download time: 0.506, 57.8s left...
    Download time: 1.488, 54.3s left...
    Download time: 0.594, 49.7s left...
    Download time: 0.521, 46.0s left...
    Download time: 1.468, 42.4s left...
    Download time: 0.571, 37.9s left...
    Download time: 3.215, 34.3s left...
    Download time: 0.838, 28.0s left...
    Download time: 0.516, 24.1s left...
    Download time: 1.557, 20.5s left...
    Download time: 1.342, 15.9s left...
    Download time: 1.265, 11.5s left...
    Download time: 1.354, 7.2s left...
    Download time: 1.778, 2.7s left...
    
    Download Times: 1.20034285714s average, 0.746259910405s stddev
    


    h1 h1-eth0:s0-eth1
    h2 h2-eth0:s0-eth2
    *** Ping: testing ping reachability
    h1 -> h2 
    h2 -> h1 
    *** Results: 0% dropped (2/2 received)


    Starting iperf server
    Starting iperf client
    Starting ping train
    Download time: 5.746, 297.0s left...
    Download time: 1.663, 288.1s left...
    Download time: 1.725, 283.4s left...
    Download time: 1.776, 278.6s left...
    Download time: 1.812, 273.8s left...
    Download time: 1.834, 268.9s left...
    Download time: 1.896, 264.0s left...
    Download time: 1.920, 259.0s left...
    Download time: 1.956, 254.0s left...
    Download time: 2.035, 249.0s left...
    Download time: 2.110, 243.9s left...
    Download time: 2.143, 238.8s left...
    Download time: 2.150, 233.6s left...
    Download time: 2.207, 228.4s left...
    Download time: 2.229, 223.1s left...
    Download time: 2.268, 217.8s left...
    Download time: 2.289, 212.4s left...
    Download time: 2.344, 207.1s left...
    Download time: 2.400, 201.6s left...
    Download time: 2.459, 196.2s left...
    Download time: 5.973, 190.6s left...
    Download time: 2.531, 181.6s left...
    Download time: 2.586, 176.0s left...
    Download time: 2.611, 170.4s left...
    Download time: 2.604, 164.7s left...
    Download time: 2.644, 159.0s left...
    Download time: 2.746, 153.3s left...
    Download time: 2.772, 147.4s left...
    Download time: 2.791, 141.5s left...
    Download time: 4.302, 135.6s left...
    Download time: 1.513, 128.3s left...
    Download time: 1.576, 123.7s left...
    Download time: 1.640, 119.0s left...
    Download time: 1.661, 114.3s left...
    Download time: 1.736, 109.5s left...
    Download time: 1.757, 104.7s left...
    Download time: 1.860, 99.9s left...
    Download time: 1.838, 94.9s left...
    Download time: 1.902, 90.0s left...
    Download time: 1.949, 85.1s left...
    Download time: 1.986, 80.1s left...
    Download time: 2.004, 75.0s left...
    Download time: 2.067, 69.9s left...
    Download time: 2.121, 64.8s left...
    Download time: 2.136, 59.6s left...
    Download time: 2.234, 54.4s left...
    Download time: 2.235, 49.1s left...
    Download time: 2.292, 43.7s left...
    Download time: 2.286, 38.4s left...
    Download time: 2.337, 33.0s left...
    Download time: 2.423, 27.6s left...
    Download time: 2.442, 22.0s left...
    Download time: 2.474, 16.5s left...
    Download time: 2.487, 10.9s left...
    Download time: 2.577, 5.3s left...
    
    Download Times: 2.32827272727s average, 0.812504757011s stddev
    


## Part B: Plotting Results

In this part of the assignment, you will analyze your measurements by plotting the variations in congestion window, queue length, and ping RTT versus time. We have provided plotting functions for each of these measurements, which are called in the following already complete `plot_measurements()` function. 



```python
%matplotlib inline
from plot_cwnd import plot_congestion_window
from plot_qsize import plot_queue_length
from plot_ping import plot_ping_rtt

def plot_measurements(experiment_name_list, cwnd_histogram=False):
    
    # plot the congestion window over time
    for name in experiment_name_list:
        cwnd_file = "{}_cwnd.txt".format(name)
        plot_congestion_window(cwnd_file, histogram=cwnd_histogram)
    
    # plot the queue size over time
    for name in experiment_name_list:
        qsize_file = "{}_qsize.txt".format(name)
        plot_queue_length(qsize_file)
    
    # plot the ping RTT over time
    for name in experiment_name_list:
        ping_file = "{}_pings.txt".format(name)
        plot_ping_rtt(ping_file)
```

Now you need to call the `plot_measurements` function such that the `experiment_name_list` argument is list of the `experiment_name` arguments you used to run `bufferbloat()` above.  This should generate 6 plots with the results of the experiments.


```python
#TODO: Call plot_measurements() to plot your results
experiment_name_list = ["experiment_20_packets", "experiment_100_packets"]
plot_measurements(experiment_name_list)
```


![png](output_25_0.png)



![png](output_25_1.png)



![png](output_25_2.png)



![png](output_25_3.png)



![png](output_25_4.png)



![png](output_25_5.png)


## Part C: Analysis

In this part of the assignment, you will answer some questions about TCP and bufferbloat using your simulations and the plots from the previous section.  This questions are intentionally open-ended and many have multiple correct answers.  There is no required answer length, but attempt to be both thorough and concise.  1-2 sentences is probably too short. More than 2-3 paragraphs is probably too long. 

Take some time first to think about the simulation you just performed. The simulation was set up like a home network with a home computer connected to a remote server through a router. The link from the router to the server had much lower bandwidth than the link from the home computer to the router. The independent variable in the simulation was the maximum length of the buffer of packets waiting to be sent from the router to the server. 

There were 3 sources of traffic:
1. A long-lasting TCP session (creating using iperf) sending a high volume of traffic from the home computer to the server.
2. Regularly spaced pings and ping replies to and from the home computer and the server
3. Regularly spaced attempts to download a website (using HTTP over TCP) from the home computer to the server.

As you (hopefully) discovered through the experiment, increasing the length of the packet buffer on the router significantly reduced performance by both ping RTT and HTTP download rate metrics. 

### Questions

#### Q1.
What computer networks other than a home network might have a configuration like the one you simulated?

#### A1.
*TODO:*

    1.公共Wi-Fi热点：由咖啡馆、机场或酒店提供的公共Wi-Fi热点可能具有配置，其中热点与互联网之间的链路带宽较低，与客户端到热点的链路相比。当许多用户同时连接并生成流量时，这可能会导致缓冲膨胀。
    
    2.移动网络：在移动网络的背景下，移动塔通常具有不同的回程容量，这可能会导致上行带宽明显低于下行带宽的情况。这种情况与家庭网络模拟有些相似，因为涉及到路由器和网络设备的使用。.

#### Q2.
Write a symbolic equation to describe the relation between RTT and queue size. 

The symbolic equation should be generalized to any queue size. Basically, consider a snapshot of a system at one point of time, and use queue size and link delays parametrically to compute the RTT

An example (incorrect) symbolic equation: 
$$RTT = kq^2$$
where $k$ is a constant factor and $q$ is the number of packets in the queue. Your equation is not limited to $k$ and $q$. 

#### A2.
*TODO: your answer here. Use single dollar signs for inline latex math formatting and double dollar signs for block latex math formatting.*

$RTT$（往返时延）与队列大小之间的关系通常可以用一个符号方程表示为:

$$RTT = R + \frac{Q}{B}$$

其中：

$RTT$ 是往返时延。

$R$ 代表固有的传输延迟（如链路延迟）。

$Q$ 代表队列中的平均包数。

$B$ 代表链路带宽。

这个方程描述了RTT与队列大小和链路带宽之间的关系。队列中包的数量增加（$Q$ 增加），RTT 也会随之增加。


#### Q3.  
Describe in technical terms why increasing buffer size reduces performance (RTTs and webpage download times), causing the bufferbloat effect.  Be sure to explicitly reference the plots you generated and the relationship between TCP congestion control and buffer size. *This is the most important question and will be weighted correspondingly more.*

#### A3.
*TODO: your answer here.*

增加缓冲区大小会导致性能降低，引发缓冲膨胀效应的技术原因如下：

增加的排队时延：通过增加缓冲区大小，网络设备（如路由器）可以存储更多的数据包，但这也会增加数据包在排队中等待传输的时间。当数据包在缓冲区中等待时，它们会经历排队时延，这会增加往返时延（RTT）。

拥塞控制和TCP窗口动态性：TCP（传输控制协议）是一种流行的协议，用于在网络中传输数据。TCP具有拥塞控制机制，它动态调整数据传输速率以避免网络拥塞。当缓冲区变得更大时，TCP流往往会充分利用这些缓冲区，导致数据包在排队中等待更长的时间。这降低了TCP窗口的动态性，使其难以快速适应网络拥塞情况，从而增加了RTT。

更大的排队时延导致不稳定性：更大的缓冲区大小会导致数据包在排队中积累，而不会迅速传输。这会导致排队时延的不稳定性，使RTT的变化更加剧烈。图表中可能会观察到这种不稳定性，RTT呈现出锯齿状的行为，这就是著名的“锯齿现象”。

Web页面下载时间增加：与RTT类似，更大的排队时延会导致网页下载时间延长。当用户尝试访问网页时，HTTP请求和响应的往返时间增加，从而使网页的加载时间增加。

在生成的图表中，可以观察到以下关系：

随着缓冲区大小的增加，RTT和HTTP下载时间也增加。
与缓冲区大小相关的锯齿状现象，这是RTT不稳定性的明显标志。
缓冲区大小对TCP拥塞控制机制的影响，导致RTT的波动和性能降低。

增大缓冲区大小可以暂时存储更多数据，但这会导致排队时延增加，降低TCP的灵活性，使RTT不稳定，并最终降低网络性能，导致缓冲膨胀效应。在网络设计中需要谨慎配置缓冲区大小，以平衡延迟和性能之间的权衡。

#### Q4. 
Re-describe the cause of the bufferbloat effect using a non-technical analogy to something other than computer networking.  It is important to be able to describe technical content such that a layperson can understand, and generating analogies often helps your own reasoning. 

#### A4.
*TODO: your answer here.*

自助餐餐厅与盘子大小：想象你正在一家排队取餐的自助餐餐厅用餐。这家餐厅提供两种不同尺寸的餐盘：

小盘子：一种是小盘子，只能容纳一两份食物。因此，当你选择食物时，你需要多次去自助台，但你不必等待太长时间就可以再拿到食物从而吃饱，因为每个人的盘子都很小。

大盘子：另一种是大盘子，可以容纳很多食物。但由于盘子很大，当你选择食物后，你必须等待一段时间，直到自助台上其他人拿大盘子都选择好食物后，才能再去拿另一盘食物，慢慢吃饱。

这个例子类似于缓冲膨胀效应。在第一种情况下，小盘子（狭窄缓冲区）意味着你需要多次取食物，但等待时间很短。而在第二种情况下，大盘子（宽缓冲区）意味着你可以一次取很多食物，但等待时间更长。就像网络中的大缓冲区可能导致数据包等待时间增加一样，大盘子可能会导致等待时间增加，从而降低了用餐体验。

#### Q5. 
Is the bufferbloat effect specific to the type of network, traffic, and/or TCP congestion control algorithm we simulated, or is it a general phenomenon?

Are there any times when increasing router buffer size would improve performance? If so, give an example.  If not, explain why not. 

#### A5.
*TODO: your answer here.*

缓冲膨胀效应并不特定于模拟的网络类型、流量或TCP拥塞控制算法，它是一个普遍存在的现象。缓冲膨胀效应可以在各种类型的网络和流量情况下出现，无论是家庭网络还是企业网络，无论是Web浏览、文件下载还是视频流，都可能受到影响。这是一个通用的现象，因为它的根本原因是与缓冲区大小的不适当配置有关。

在一些情况下，增加路由器缓冲区大小可以改善性能。比如：

批量数据传输：当网络用于大规模数据传输，如备份、数据复制或大文件传输时，增大缓冲区可以提高性能。这是因为在这种情况下，网络通常具有大带宽和高延迟，而且数据量巨大。通过增大缓冲区，可以更好地利用可用的带宽，减少数据包在传输过程中的等待时间，从而加速数据传输。然而，这仅适用于特定类型的流量，而不适用于实时应用程序或低延迟应用程序。

#### Q6.
Identify and describe a way to mitigate the bufferbloat problem without reducing buffer sizes.  

#### A6.
*TODO: your answer here.*

路由器使用随机性来决定是否丢弃传入的数据包，以提醒发送方减慢发送速度，从而避免网络拥塞。这里基于两个关键参数：最小和最大门限，来设计以下算法。

基本原理：
当缓冲区中的数据包数量接近最大门限时，路由器开始随机丢弃部分数据包，而不是等到缓冲区完全溢出。这个随机性使得发送方难以预测何时会发生丢包，因此发送方倾向于减缓发送速度，以降低拥塞的风险。当缓冲区中的数据包数量接近最小门限时，路由器停止丢包，以确保不浪费可用带宽。

## Submission 

**Remember to "Save and Checkpoint" (from the "File" menu above) before you leave the notebook or close your tab.**

